<template>
  <div>
    <h1>首页</h1>
    <p>这是首页的内容</p>
  </div>
</template>